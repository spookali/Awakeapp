package com.example.rachel.test;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.hardware.usb.UsbDevice;
import android.os.Handler;
import android.widget.TextView;
import android.hardware.usb.UsbManager;

import com.felhr.usbserial.UsbSerialDevice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickMethod(View view) {
        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        HashMap<String, UsbDevice> devices = manager.getDeviceList();
        Iterator<UsbDevice> deviceIterator = devices.values().iterator();
        while(deviceIterator.hasNext()){
            UsbDevice device = deviceIterator.next();
            Log.i("Found", device.toString());

            if (device.getDeviceName().equals("0x2341")) {

                // do your logic....
            }
            //your code
        }

//        if (!devices.isEmpty()) {
//            UsbDevice device = devices.get("deviceName");
//
//            Log.i("MEOW!", device.toString());
//            boolean keep = true;
//            for (Object entry : UsbDevices.entrySet()) {
//                UsbDevice device = (UsbDevice) getSystemService(Context.);
//                device = entry.getValue();
//                int deviceVID = device.getVendorId();
//                if (deviceVID == 0x2341)//Arduino Vendor ID
//                {
//                    PendingIntent pi = PendingIntent.getBroadcast(this, 0,
//                            new Intent(ACTION_USB_PERMISSION), 0);
//                    UsbManager manager1 = (UsbManager) getSystemService(Context.USB_SERVICE);
//                    manager1.requestPermission(device, pi);
//                    keep = false;
//                } else {
//                    connection = null;
//                    device = null;
//                }
//
//                if (!keep)
//                    break;
//            }
        }
    }