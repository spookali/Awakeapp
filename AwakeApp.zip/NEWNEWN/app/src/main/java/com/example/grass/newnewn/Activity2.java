package com.example.grass.newnewn;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class Activity2 extends AppCompatActivity {

    Button button, button2, button3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        final MediaPlayer alarmSound = MediaPlayer.create(Activity2.this, R.raw.meow);
        alarmSound.start();

/*        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //grab button press information onto textfile
                alarmSound.stop();
            }
        });



        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View b) {
                //grab button press information onto textfile
                alarmSound.stop();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View n) {
                //grab button press information onto textfile
                alarmSound.stop();
            }
        });
*/

    }
}
